const atsCtx = document.getElementById('atsChart');

if (atsCtx) {

    new Chart(atsCtx, {

        type: 'bar',

        data: {

            labels: ['ATS Score'],

            datasets: [{

                label: 'Score',

                data: [85],

                borderWidth: 1
            }]
        }
    });
}

const skillsCtx = document.getElementById('skillsChart');

if (skillsCtx) {

    new Chart(skillsCtx, {

        type: 'pie',

        data: {

            labels: [
                'Python',
                'SQL',
                'Flask',
                'React'
            ],

            datasets: [{

                data: [25, 25, 25, 25]
            }]
        }
    });
}   