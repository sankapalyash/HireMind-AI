import re

def extract_candidate_name(text):

    lines = text.split('\n')

    for line in lines[:10]:

        clean_line = line.strip()

        if len(clean_line.split()) >= 2:

            if re.match(
                r'^[A-Za-z ]+$',
                clean_line
            ):

                return clean_line

    return "Unknown Candidate"