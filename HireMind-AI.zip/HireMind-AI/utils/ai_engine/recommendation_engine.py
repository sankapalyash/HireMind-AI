role_skill_map = {

    "Backend Developer": [
        "python",
        "flask",
        "sql",
        "api",
        "docker",
        "aws"
    ],

    "Data Analyst": [
        "sql",
        "excel",
        "power bi",
        "python"
    ],

    "Frontend Developer": [
        "html",
        "css",
        "javascript",
        "react"
    ],

    "ML Engineer": [
        "python",
        "machine learning",
        "tensorflow",
        "pandas"
    ]
}

def get_missing_skills(role, found_skills):

    required_skills = role_skill_map.get(role, [])

    missing_skills = []

    for skill in required_skills:

        if skill not in found_skills:
            missing_skills.append(skill)

    return missing_skills


def generate_recommendations(missing_skills):

    recommendations = []

    for skill in missing_skills:

        recommendations.append(
            f"Learn {skill}"
        )

    return recommendations