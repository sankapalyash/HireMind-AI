def calculate_ats_score(skills_count):

    base_score = 50

    score = base_score + (skills_count * 5)

    if score > 100:
        score = 100

    return score