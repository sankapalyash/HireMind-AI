APP_NAME = 'HireMind AI'
VERSION = '1.0'