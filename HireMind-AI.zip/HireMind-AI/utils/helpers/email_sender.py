import smtplib
from email.message import EmailMessage

def send_email_report(
    sender_email,
    sender_password,
    receiver_email,
    pdf_path
):

    msg = EmailMessage()

    msg['Subject'] = 'HireMind AI Resume Analysis Report'

    msg['From'] = sender_email

    msg['To'] = receiver_email

    msg.set_content(
        'Your AI Resume Analysis Report is attached.'
    )

    with open(pdf_path, 'rb') as f:

        file_data = f.read()

        msg.add_attachment(
            file_data,
            maintype='application',
            subtype='pdf',
            filename='Resume_Report.pdf'
        )

    with smtplib.SMTP_SSL(
        'smtp.gmail.com',
        465
    ) as smtp:

        smtp.login(
            sender_email,
            sender_password
        )

        smtp.send_message(msg)